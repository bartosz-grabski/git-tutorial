class TextDrawer:
	def setFont(self, font):
		pass

	def draw(self, text):
		pass
