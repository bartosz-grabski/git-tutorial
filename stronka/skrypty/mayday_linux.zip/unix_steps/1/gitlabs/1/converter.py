t = getText()
f = FontLoader().loadFont('fancyFont/')

d = TextDrawer()
d.setFont(f)
d.draw(t)
