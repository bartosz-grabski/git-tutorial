github_url="git@github.com:Mequrel/bit-workshop.git"
