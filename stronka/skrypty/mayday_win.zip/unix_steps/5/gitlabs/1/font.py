class Font:
	def __init__(self, name):
		self.name = name
		self.letters = {}

class FontLoader:
	def loadFont(self, directory):
		pass
