class Font:
	pass

class FontLoader:
	def loadFont(self, directory):
		pass
